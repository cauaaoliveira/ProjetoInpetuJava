
package inpetu;

import inpetu.model.Agendamento;
import inpetu.model.Contato;
import inpetu.model.Espaco;

import inpetu.repository.IContatoRepository;
import inpetu.repository.IEspacoRepository;
import inpetu.repository.IAgendamentoRepository;

import inpetu.repository.memory.ContatoMemoryRepository;
import inpetu.repository.memory.EspacoMemoryRepository;
import inpetu.repository.memory.AgendamentoMemoryRepository;

import inpetu.service.ContatoService;
import inpetu.service.EspacoService;
import inpetu.service.AgendamentoService;

import java.time.LocalDate;
import java.time.LocalTime;

public class Application {

    public static void main(String[] args) {

        // ==========================================
        // 1. INICIALIZAÇÃO DOS REPOSITÓRIOS
        // ==========================================

        IContatoRepository contatoRepository =
                new ContatoMemoryRepository();

        IEspacoRepository espacoRepository =
                new EspacoMemoryRepository();

        IAgendamentoRepository agendamentoRepository =
                new AgendamentoMemoryRepository();


        // ==========================================
        // 2. INICIALIZAÇÃO DOS SERVICES
        // ==========================================

        ContatoService contatoService =
                new ContatoService(contatoRepository);

        EspacoService espacoService =
                new EspacoService(espacoRepository, agendamentoRepository);

        AgendamentoService agendamentoService =
                new AgendamentoService(
                        agendamentoRepository,
                        contatoRepository,
                        espacoRepository
                );


        System.out.println("====================================");
        System.out.println("       TESTES DO SISTEMA INPETU");
        System.out.println("====================================");


        // ==========================================
        // 3. TESTES DE CONTATO
        // ==========================================

        System.out.println("\n========== TESTES DE CONTATO ==========");

        Contato contato1 = new Contato("Ana Martins");
        Contato contato2 = new Contato("João Silva");

        // Cadastro
        contatoService.cadastrar(contato1);
        contatoService.cadastrar(contato2);

        System.out.println("\nContatos cadastrados:");
        System.out.println(contato1);
        System.out.println(contato2);

        // Consultar
        System.out.println("\nConsulta de contato:");
        System.out.println(contatoService.buscarPorId(contato1.getId()));

        // Contato inexistente
        testarBloqueio("Consultar contato inexistente", () ->
                contatoService.buscarPorId(999));

        // ID duplicado
        testarBloqueio("Cadastrar contato com ID duplicado", () ->
                contatoRepository.salvar(
                        new Contato("Contato duplicado", contato1.getId())
                ));

        // Editar
        contatoService.editar(contato2.getId(), "João Oliveira");

        System.out.println("\nContato editado:");
        System.out.println(contatoService.buscarPorId(contato2.getId()));

        // Listar
        System.out.println("\nTodos os contatos:");
        contatoService.listar().forEach(System.out::println);


        // ==========================================
        // 4. TESTES DE ESPAÇO
        // ==========================================

        System.out.println("\n========== TESTES DE ESPAÇO ==========");

        Espaco sala1 = new Espaco(
                "Sala Araucária",
                "Sala",
                12,
                "Bloco A - 2º andar",
                "Sala para reuniões"
        );

        Espaco sala2 = new Espaco(
                "Sala Ipê",
                "Sala",
                8,
                "Bloco B - 1º andar",
                "Sala para pequenos encontros"
        );

        // Cadastro
        espacoService.cadastrar(sala1);
        espacoService.cadastrar(sala2);

        System.out.println("\nEspaços cadastrados:");
        System.out.println(sala1);
        System.out.println(sala2);

        // Consultar
        System.out.println("\nConsulta de espaço:");
        System.out.println(espacoService.buscarPorId(sala1.getId()));

        // Espaço inexistente
        testarBloqueio("Consultar espaço inexistente", () ->
                espacoService.buscarPorId(999));

        // ID duplicado
        testarBloqueio("Cadastrar espaço com ID duplicado", () -> {
            Espaco duplicado = new Espaco(
                    "Sala duplicada", "Sala", 10,
                    "Bloco C", "Teste"
            );

            duplicado.setId(sala1.getId());
            espacoRepository.salvar(duplicado);
        });

        // Editar
        espacoService.editar(
                sala2.getId(),
                "Sala Ipê Atualizada",
                "Sala de reunião",
                15,
                "Bloco B - 2º andar",
                "Sala atualizada"
        );

        System.out.println("\nEspaço editado:");
        System.out.println(espacoService.buscarPorId(sala2.getId()));

        // Listar
        System.out.println("\nTodos os espaços:");
        espacoService.listar().forEach(System.out::println);


        // ==========================================
        // 5. TESTES DE AGENDAMENTO
        // ==========================================

        System.out.println("\n========== TESTES DE AGENDAMENTO ==========");

        LocalDate data = LocalDate.now().plusDays(1);

        LocalTime inicio = LocalTime.of(13, 0);
        LocalTime fim = LocalTime.of(14, 0);

        // Reserva válida
        Agendamento reserva1 = new Agendamento(
                contato1,
                "InPETU",
                sala1,
                data,
                inicio,
                fim,
                "Reunião de equipe",
                "Precisa de projetor"
        );

        agendamentoService.solicitar(reserva1);

        System.out.println("\nReserva cadastrada:");
        System.out.println(reserva1);


        // Reserva sem contato cadastrado
        testarBloqueio("Reserva sem contato cadastrado", () -> {

            Contato contatoInexistente =
                    new Contato("Contato não cadastrado");

            Agendamento reserva = new Agendamento(
                    contatoInexistente,
                    "InPETU",
                    sala2,
                    data,
                    inicio,
                    fim,
                    "Reunião",
                    "Teste"
            );

            agendamentoService.solicitar(reserva);
        });


        // Reserva sem espaço cadastrado
        testarBloqueio("Reserva sem espaço cadastrado", () -> {

            Espaco espacoInexistente = new Espaco(
                    "Espaço inexistente",
                    "Sala",
                    10,
                    "Bloco X",
                    "Teste"
            );

            Agendamento reserva = new Agendamento(
                    contato2,
                    "InPETU",
                    espacoInexistente,
                    data,
                    inicio,
                    fim,
                    "Reunião",
                    "Teste"
            );

            agendamentoService.solicitar(reserva);
        });


        // Mesmo contato no mesmo horário
        testarBloqueio("Contato repetido no mesmo horário", () -> {

            Agendamento reserva = new Agendamento(
                    contato1,
                    "InPETU",
                    sala2,
                    data,
                    inicio,
                    fim,
                    "Outra reunião",
                    "Teste"
            );

            agendamentoService.solicitar(reserva);
        });


        // Mesmo espaço no mesmo horário
        testarBloqueio("Espaço repetido no mesmo horário", () -> {

            Agendamento reserva = new Agendamento(
                    contato2,
                    "InPETU",
                    sala1,
                    data,
                    inicio,
                    fim,
                    "Outra reunião",
                    "Teste"
            );

            agendamentoService.solicitar(reserva);
        });


        // Consultar reserva
        System.out.println("\nConsulta de agendamento:");
        System.out.println(
                agendamentoService.buscarPorId(reserva1.getId())
        );


        // Reserva inexistente
        testarBloqueio("Consultar reserva inexistente", () ->
                agendamentoService.buscarPorId(999));


        // ID duplicado
        testarBloqueio("Cadastrar reserva com ID duplicado", () -> {

            Agendamento duplicada = new Agendamento(
                    contato2,
                    "InPETU",
                    sala2,
                    data,
                    LocalTime.of(15, 0),
                    LocalTime.of(16, 0),
                    "Teste de duplicidade",
                    "Teste"
            );

            duplicada.setId(reserva1.getId());

            agendamentoRepository.salvar(duplicada);
        });


        // Editar reserva
        agendamentoService.editar(
                reserva1.getId(),
                contato1.getId(),
                sala1.getId(),
                "InPETU",
                data,
                LocalTime.of(15, 0),
                LocalTime.of(16, 0),
                "Reunião atualizada",
                "Projetor e computador"
        );

        System.out.println("\nReserva editada:");
        System.out.println(
                agendamentoService.buscarPorId(reserva1.getId())
        );


        // Impedir alteração do ID
        testarBloqueio("Alterar ID de uma reserva", () ->
                reserva1.setId(reserva1.getId() + 100));


        // Listar reservas
        System.out.println("\nTodas as reservas:");
        agendamentoService.listar().forEach(System.out::println);


        // ==========================================
        // 6. TESTE DE EXCLUSÃO DE ESPAÇO
        // ==========================================

        System.out.println("\n========== TESTE DE EXCLUSÃO ==========");

        // Deve bloquear, pois sala1 possui uma reserva
        testarBloqueio(
                "Excluir espaço com agendamento vinculado",
                () -> espacoService.excluir(sala1.getId())
        );

        // Deve permitir, pois sala2 não possui reserva
        espacoService.excluir(sala2.getId());

        System.out.println("\nEspaço sem agendamento excluído com sucesso!");


        // ==========================================
        // 7. TESTE DE EXCLUSÃO DE CONTATO
        // ==========================================

        System.out.println("\n========== EXCLUSÃO DE CONTATO ==========");

        // João não possui reserva vinculada
        contatoService.excluir(contato2.getId());

        System.out.println("Contato sem reserva excluído com sucesso!");


        // ==========================================
        // 8. RESULTADO FINAL
        // ==========================================

        System.out.println("\n====================================");
        System.out.println("       TESTES FINALIZADOS");
        System.out.println("====================================");

        System.out.println("\nContatos restantes:");
        contatoService.listar().forEach(System.out::println);

        System.out.println("\nEspaços restantes:");
        espacoService.listar().forEach(System.out::println);

        System.out.println("\nAgendamentos restantes:");
        agendamentoService.listar().forEach(System.out::println);
    }


    // ==========================================
    // MÉTODO AUXILIAR PARA TESTAR ERROS
    // ==========================================

    private static void testarBloqueio(
            String descricao,
            Runnable acao) {

        try {
            acao.run();

            System.out.println(
                    "[FALHA] O sistema deveria bloquear: " + descricao
            );

        } catch (IllegalArgumentException e) {

            System.out.println(
                    "[OK] " + descricao + " -> " + e.getMessage()
            );
        }
    }
}
