
package inpetu.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Agendamento {

    private int id;
    private Contato contato;
    private String empresa;
    private Espaco espaco;
    private LocalDate data;
    private LocalTime horaInicio;
    private LocalTime horaFim;
    private String finalidade;
    private String observacoes;
    private String status;

    public Agendamento(Contato contato, String empresa, Espaco espaco,
                       LocalDate data, LocalTime horaInicio, LocalTime horaFim,
                       String finalidade, String observacoes) {

        this.id = 0;
        this.contato = contato;
        this.empresa = empresa;
        this.espaco = espaco;
        this.data = data;
        this.horaInicio = horaInicio;
        this.horaFim = horaFim;
        this.finalidade = finalidade;
        this.observacoes = observacoes;
        this.status = "Solicitado";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("O ID deve ser maior que zero.");
        }

        if (this.id != 0 && this.id != id) {
            throw new IllegalArgumentException(
                    "Não é permitido alterar o ID do agendamento.");
        }

        this.id = id;
    }

    public Contato getContato() {
        return contato;
    }

    public void setContato(Contato contato) {
        this.contato = contato;
    }

    // Mantém acesso ao nome do solicitante através do contato
    public String getSolicitante() {
        return contato == null ? null : contato.getNome();
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public Espaco getEspaco() {
        return espaco;
    }

    public void setEspaco(Espaco espaco) {
        this.espaco = espaco;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(LocalTime horaInicio) {
        this.horaInicio = horaInicio;
    }

    public LocalTime getHoraFim() {
        return horaFim;
    }

    public void setHoraFim(LocalTime horaFim) {
        this.horaFim = horaFim;
    }

    public String getFinalidade() {
        return finalidade;
    }

    public void setFinalidade(String finalidade) {
        this.finalidade = finalidade;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Agendamento{" +
                "id=" + id +
                ", contato='" + getSolicitante() + '\'' +
                ", espaco='" + (espaco == null ? "" : espaco.getNome()) + '\'' +
                ", data=" + data +
                ", horario=" + horaInicio + "-" + horaFim +
                ", status='" + status + '\'' +
                '}';
    }
}
