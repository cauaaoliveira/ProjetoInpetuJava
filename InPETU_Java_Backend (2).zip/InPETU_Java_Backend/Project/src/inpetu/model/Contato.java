
package inpetu.model;

public class Contato {
    private int id;
    private String nome;

    public Contato(String nome) {
        this.nome = nome;
        this.id = 0;
    }

    public Contato(String nome, int id) {
        this.nome = nome;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public void setId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("O ID deve ser maior que zero.");
        }

        if (this.id != 0 && this.id != id) {
            throw new IllegalArgumentException("Não é permitido alterar o ID do contato.");
        }

        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "Contato{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                '}';
    }
}

