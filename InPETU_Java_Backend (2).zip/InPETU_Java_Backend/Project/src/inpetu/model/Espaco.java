
package inpetu.model;

public class Espaco {
    private int id;
    private String nome;
    private String tipo;
    private int capacidade;
    private String localizacao;
    private String descricao;
    private boolean ativo;

    public Espaco(String nome, String tipo, int capacidade, String localizacao, String descricao) {
        this.id = 0;
        this.nome = nome;
        this.tipo = tipo;
        this.capacidade = capacidade;
        this.localizacao = localizacao;
        this.descricao = descricao;
        this.ativo = true;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("O ID deve ser maior que zero.");
        }

        if (this.id != 0 && this.id != id) {
            throw new IllegalArgumentException("Não é permitido alterar o ID do espaço.");
        }

        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    public String getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    @Override
    public String toString() {
        return "Espaco{id=" + id + ", nome='" + nome + "', tipo='" + tipo +
                "', capacidade=" + capacidade + ", localizacao='" + localizacao + "'}";
    }
}
