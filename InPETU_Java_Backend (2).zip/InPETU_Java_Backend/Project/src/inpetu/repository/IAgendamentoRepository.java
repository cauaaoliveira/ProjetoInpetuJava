
package inpetu.repository;

import inpetu.model.Agendamento;

import java.util.List;
import java.util.Optional;

public interface IAgendamentoRepository {

    void salvar(Agendamento agendamento);

    Optional<Agendamento> buscarPorId(int id);

    List<Agendamento> listarTodos();

    void atualizar(Agendamento agendamento);
}
