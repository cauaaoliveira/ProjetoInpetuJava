
package inpetu.repository;

import inpetu.model.Contato;

import java.util.List;
import java.util.Optional;

public interface IContatoRepository {

    Optional<Contato> buscarPorId(int id);

    void salvar(Contato contato);

    List<Contato> listarTodos();

    void atualizar(Contato contato);

    void excluir(int id);
}
