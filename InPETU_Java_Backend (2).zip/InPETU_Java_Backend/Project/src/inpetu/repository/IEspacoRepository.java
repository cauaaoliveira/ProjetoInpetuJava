package inpetu.repository;

import inpetu.model.Espaco;
import java.util.List;
import java.util.Optional;

public interface IEspacoRepository {
    void salvar(Espaco espaco);
    Optional<Espaco> buscarPorId(int id);
    List<Espaco> listarTodos();
    void excluir(int id);
    void atualizar(Espaco espaco);
}
