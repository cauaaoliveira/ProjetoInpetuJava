
package inpetu.repository.memory;

import inpetu.model.Agendamento;
import inpetu.repository.IAgendamentoRepository;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class AgendamentoMemoryRepository implements IAgendamentoRepository {

    private final Map<Integer, Agendamento> armazenamento = new LinkedHashMap<>();
    private int proximoId = 1;

    @Override
    public void salvar(Agendamento agendamento) {

        if (agendamento == null) {
            throw new IllegalArgumentException("O agendamento é obrigatório.");
        }

        if (agendamento.getId() == 0) {
            agendamento.setId(proximoId++);
        } else {

            if (armazenamento.containsKey(agendamento.getId())) {
                throw new IllegalArgumentException(
                        "Já existe um agendamento com esse ID.");
            }

            if (agendamento.getId() >= proximoId) {
                proximoId = agendamento.getId() + 1;
            }
        }

        armazenamento.put(agendamento.getId(), agendamento);
    }

    @Override
    public Optional<Agendamento> buscarPorId(int id) {
        return Optional.ofNullable(armazenamento.get(id));
    }

    @Override
    public List<Agendamento> listarTodos() {
        return List.copyOf(armazenamento.values());
    }

    @Override
    public void atualizar(Agendamento agendamento) {

        if (agendamento == null) {
            throw new IllegalArgumentException("O agendamento é obrigatório.");
        }

        if (!armazenamento.containsKey(agendamento.getId())) {
            throw new IllegalArgumentException("Agendamento não encontrado.");
        }

        armazenamento.put(agendamento.getId(), agendamento);
    }
}
