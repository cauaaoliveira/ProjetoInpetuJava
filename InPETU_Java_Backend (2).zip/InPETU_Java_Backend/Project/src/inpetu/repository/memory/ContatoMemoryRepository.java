
package inpetu.repository.memory;

import inpetu.model.Contato;
import inpetu.repository.IContatoRepository;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class ContatoMemoryRepository implements IContatoRepository {

    private final Map<Integer, Contato> armazenamento;
    private int proximoId = 1;

    public ContatoMemoryRepository() {
        this.armazenamento = new LinkedHashMap<>();
    }

    @Override
    public Optional<Contato> buscarPorId(int id) {
        return Optional.ofNullable(armazenamento.get(id));
    }

    @Override
    public void salvar(Contato contato) {

        if (contato == null) {
            throw new IllegalArgumentException("O contato é obrigatório.");
        }

        if (contato.getId() == 0) {
            contato.setId(proximoId++);
        } else {
            if (armazenamento.containsKey(contato.getId())) {
                throw new IllegalArgumentException("Já existe um contato com esse ID.");
            }

            proximoId = Math.max(proximoId, contato.getId() + 1);
        }

        armazenamento.put(contato.getId(), contato);
    }

    @Override
    public List<Contato> listarTodos() {
        return List.copyOf(armazenamento.values());
    }

    @Override
    public void atualizar(Contato contato) {

        if (contato == null) {
            throw new IllegalArgumentException("O contato é obrigatório.");
        }

        if (!armazenamento.containsKey(contato.getId())) {
            throw new IllegalArgumentException("Contato não encontrado.");
        }

        armazenamento.put(contato.getId(), contato);
    }

    @Override
    public void excluir(int id) {

        if (!armazenamento.containsKey(id)) {
            throw new IllegalArgumentException("Contato não encontrado.");
        }

        armazenamento.remove(id);
    }
}
