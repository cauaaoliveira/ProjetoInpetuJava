package inpetu.repository.memory;

import inpetu.model.Espaco;
import inpetu.repository.IEspacoRepository;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class EspacoMemoryRepository implements IEspacoRepository {

    private final Map<Integer, Espaco> armazenamento = new LinkedHashMap<>();
    private int proximoId = 1;

    @Override
    public Optional<Espaco> buscarPorId(int id) {
        return Optional.ofNullable(armazenamento.get(id));
    }

    @Override
    public void salvar(Espaco espaco) {

        if (espaco == null) {
            throw new IllegalArgumentException("O espaço é obrigatório.");
        }

        if (espaco.getId() == 0) {
            espaco.setId(proximoId++);
        } else {

            if (armazenamento.containsKey(espaco.getId())) {
                throw new IllegalArgumentException("Já existe um espaço com esse ID.");
            }

            if (espaco.getId() >= proximoId) {
                proximoId = espaco.getId() + 1;
            }
        }

        armazenamento.put(espaco.getId(), espaco);
    }

    @Override
    public List<Espaco> listarTodos() {
        return List.copyOf(armazenamento.values());
    }

    @Override
    public void atualizar(Espaco espaco) {

        if (espaco == null) {
            throw new IllegalArgumentException("O espaço é obrigatório.");
        }

        if (!armazenamento.containsKey(espaco.getId())) {
            throw new IllegalArgumentException("Espaço não encontrado.");
        }

        armazenamento.put(espaco.getId(), espaco);
    }

    @Override
    public void excluir(int id) {

        if (!armazenamento.containsKey(id)) {
            throw new IllegalArgumentException("Espaço não encontrado.");
        }

        armazenamento.remove(id);
    }
}
