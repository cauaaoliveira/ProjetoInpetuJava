
package inpetu.service;

import inpetu.model.Agendamento;
import inpetu.model.Contato;
import inpetu.model.Espaco;
import inpetu.repository.IAgendamentoRepository;
import inpetu.repository.IContatoRepository;
import inpetu.repository.IEspacoRepository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class AgendamentoService {

    private final IAgendamentoRepository agendamentoRepository;
    private final IContatoRepository contatoRepository;
    private final IEspacoRepository espacoRepository;

    public AgendamentoService(
            IAgendamentoRepository agendamentoRepository,
            IContatoRepository contatoRepository,
            IEspacoRepository espacoRepository) {

        this.agendamentoRepository = agendamentoRepository;
        this.contatoRepository = contatoRepository;
        this.espacoRepository = espacoRepository;
    }

    // Verificar disponibilidade de horário
    public boolean horarioDisponivel(
            int espacoId,
            LocalDate data,
            LocalTime inicio,
            LocalTime fim) {

        validarHorario(data, inicio, fim);

        Espaco espaco = buscarEspaco(espacoId);

        if (!espaco.isAtivo()) {
            return false;
        }

        return !existeConflito(
                0, 0, espacoId, data, inicio, fim);
    }

    // Cadastrar uma nova reserva
    public void solicitar(Agendamento agendamento) {

        if (agendamento == null) {
            throw new IllegalArgumentException(
                    "O agendamento é obrigatório.");
        }

        if (agendamento.getId() != 0) {
            throw new IllegalArgumentException(
                    "O ID deve ser gerado automaticamente.");
        }

        if (agendamento.getContato() == null) {
            throw new IllegalArgumentException(
                    "Selecione um contato para a reserva.");
        }

        if (agendamento.getEspaco() == null) {
            throw new IllegalArgumentException(
                    "Selecione um espaço para a reserva.");
        }

        if (agendamento.getFinalidade() == null
                || agendamento.getFinalidade().isBlank()) {
            throw new IllegalArgumentException(
                    "Informe a finalidade do agendamento.");
        }

        // Verifica se o contato existe no cadastro
        Contato contato = contatoRepository.buscarPorId(
                agendamento.getContato().getId()
        ).orElseThrow(() ->
                new IllegalArgumentException("Contato não encontrado."));

        // Verifica se o espaço existe no cadastro
        Espaco espaco = buscarEspaco(
                agendamento.getEspaco().getId());

        validarHorario(
                agendamento.getData(),
                agendamento.getHoraInicio(),
                agendamento.getHoraFim());

        if (!espaco.isAtivo()) {
            throw new IllegalArgumentException(
                    "O espaço está inativo e não pode receber reservas.");
        }

        // Impede conflito de contato ou de espaço
        if (existeConflito(
                0,
                contato.getId(),
                espaco.getId(),
                agendamento.getData(),
                agendamento.getHoraInicio(),
                agendamento.getHoraFim())) {

            throw new IllegalArgumentException(
                    "O contato ou o espaço já possui uma reserva nesse horário.");
        }

        // Usa os objetos que realmente estão cadastrados
        agendamento.setContato(contato);
        agendamento.setEspaco(espaco);

        agendamentoRepository.salvar(agendamento);
    }

    // Consultar reserva pelo ID
    public Agendamento buscarPorId(int id) {

        if (id <= 0) {
            throw new IllegalArgumentException(
                    "O ID deve ser maior que zero.");
        }

        return agendamentoRepository.buscarPorId(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Agendamento não encontrado."));
    }

    // Listar todas as reservas
    public List<Agendamento> listar() {
        return agendamentoRepository.listarTodos();
    }

    // Editar uma reserva sem alterar seu ID
    public void editar(
            int id,
            int contatoId,
            int espacoId,
            String empresa,
            LocalDate data,
            LocalTime inicio,
            LocalTime fim,
            String finalidade,
            String observacoes) {

        Agendamento agendamento = buscarPorId(id);

        Contato contato = contatoRepository.buscarPorId(contatoId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Contato não encontrado."));

        Espaco espaco = buscarEspaco(espacoId);

        validarHorario(data, inicio, fim);

        if (!espaco.isAtivo()) {
            throw new IllegalArgumentException(
                    "O espaço está inativo e não pode receber reservas.");
        }

        if (finalidade == null || finalidade.isBlank()) {
            throw new IllegalArgumentException(
                    "Informe a finalidade do agendamento.");
        }

        // Ignora a própria reserva ao verificar conflitos
        if (existeConflito(
                id,
                contatoId,
                espacoId,
                data,
                inicio,
                fim)) {

            throw new IllegalArgumentException(
                    "O contato ou o espaço já possui outra reserva nesse horário.");
        }

        agendamento.setContato(contato);
        agendamento.setEspaco(espaco);
        agendamento.setEmpresa(empresa);
        agendamento.setData(data);
        agendamento.setHoraInicio(inicio);
        agendamento.setHoraFim(fim);
        agendamento.setFinalidade(finalidade);
        agendamento.setObservacoes(observacoes);

        agendamentoRepository.atualizar(agendamento);
    }

    // Localizar espaço cadastrado
    private Espaco buscarEspaco(int id) {

        if (id <= 0) {
            throw new IllegalArgumentException(
                    "O ID do espaço deve ser maior que zero.");
        }

        return espacoRepository.buscarPorId(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Espaço não encontrado."));
    }

    // Verificar conflitos de horário
    private boolean existeConflito(
            int agendamentoIgnorado,
            int contatoId,
            int espacoId,
            LocalDate data,
            LocalTime inicio,
            LocalTime fim) {

        for (Agendamento existente : agendamentoRepository.listarTodos()) {

            // Não compara a reserva consigo mesma durante a edição
            if (existente.getId() == agendamentoIgnorado) {
                continue;
            }

            // Reservas canceladas não ocupam horário
            if ("Cancelado".equalsIgnoreCase(existente.getStatus())) {
                continue;
            }

            if (existente.getData() == null
                    || existente.getHoraInicio() == null
                    || existente.getHoraFim() == null) {
                continue;
            }

            boolean mesmaData = existente.getData().equals(data);

            boolean horariosSeSobrepoem =
                    inicio.isBefore(existente.getHoraFim())
                            && fim.isAfter(existente.getHoraInicio());

            if (!mesmaData || !horariosSeSobrepoem) {
                continue;
            }

            boolean mesmoEspaco =
                    existente.getEspaco() != null
                            && existente.getEspaco().getId() == espacoId;

            boolean mesmoContato =
                    contatoId > 0
                            && existente.getContato() != null
                            && existente.getContato().getId() == contatoId;

            if (mesmoEspaco || mesmoContato) {
                return true;
            }
        }

        return false;
    }

    // Validar data e horários
    private void validarHorario(
            LocalDate data,
            LocalTime inicio,
            LocalTime fim) {

        if (data == null || inicio == null || fim == null) {
            throw new IllegalArgumentException(
                    "Informe a data e os horários.");
        }

        if (!fim.isAfter(inicio)) {
            throw new IllegalArgumentException(
                    "O horário final deve ser depois do horário inicial.");
        }
    }
}
