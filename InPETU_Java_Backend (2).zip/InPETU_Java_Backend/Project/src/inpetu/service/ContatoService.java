
package inpetu.service;

import inpetu.model.Contato;
import inpetu.repository.IContatoRepository;

import java.util.List;

public class ContatoService {

    private final IContatoRepository repository;

    public ContatoService(IContatoRepository repository) {
        this.repository = repository;
    }

    // Cadastrar contato
    public void cadastrar(Contato contato) {

        if (contato == null) {
            throw new IllegalArgumentException("O contato é obrigatório.");
        }

        if (contato.getId() != 0) {
            throw new IllegalArgumentException("O ID do contato é gerado automaticamente.");
        }

        validarNome(contato.getNome());

        repository.salvar(contato);
    }

    // Consultar contato pelo ID
    public Contato buscarPorId(int id) {

        if (id <= 0) {
            throw new IllegalArgumentException("Informe um ID válido.");
        }

        return repository.buscarPorId(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Contato não encontrado."));
    }

    // Listar todos os contatos
    public List<Contato> listar() {
        return repository.listarTodos();
    }

    // Editar contato sem alterar o ID
    public void editar(int id, String novoNome) {

        validarNome(novoNome);

        Contato contato = buscarPorId(id);

        contato.setNome(novoNome);

        repository.atualizar(contato);
    }

    // Excluir contato
    public void excluir(int id) {

        Contato contato = buscarPorId(id);

        repository.excluir(contato.getId());
    }

    // Validar nome
    private void validarNome(String nome) {

        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("Informe o nome do contato.");
        }
    }
}
