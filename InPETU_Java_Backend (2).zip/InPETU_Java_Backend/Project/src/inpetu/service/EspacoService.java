
package inpetu.service;

import inpetu.model.Agendamento;
import inpetu.model.Espaco;
import inpetu.repository.IAgendamentoRepository;
import inpetu.repository.IEspacoRepository;

import java.util.List;

public class EspacoService {

    private final IEspacoRepository repository;
    private final IAgendamentoRepository agendamentoRepository;

    public EspacoService(
            IEspacoRepository repository,
            IAgendamentoRepository agendamentoRepository) {

        this.repository = repository;
        this.agendamentoRepository = agendamentoRepository;
    }

    // Cadastrar espaço
    public void cadastrar(Espaco espaco) {

        if (espaco == null) {
            throw new IllegalArgumentException("O espaço é obrigatório.");
        }

        if (espaco.getId() != 0) {
            throw new IllegalArgumentException(
                    "O ID do espaço deve ser gerado automaticamente.");
        }

        validarDados(
                espaco.getNome(),
                espaco.getTipo(),
                espaco.getCapacidade());

        repository.salvar(espaco);
    }

    // Consultar espaço pelo ID
    public Espaco buscarPorId(int id) {

        if (id <= 0) {
            throw new IllegalArgumentException(
                    "O ID deve ser maior que zero.");
        }

        return repository.buscarPorId(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Espaço não encontrado."));
    }

    // Listar espaços
    public List<Espaco> listar() {
        return repository.listarTodos();
    }

    // Editar espaço sem alterar o ID
    public void editar(
            int id,
            String nome,
            String tipo,
            int capacidade,
            String localizacao,
            String descricao) {

        Espaco espaco = buscarPorId(id);

        validarDados(nome, tipo, capacidade);

        espaco.setNome(nome);
        espaco.setTipo(tipo);
        espaco.setCapacidade(capacidade);
        espaco.setLocalizacao(localizacao);
        espaco.setDescricao(descricao);

        repository.atualizar(espaco);
    }

    // Excluir espaço somente se não possuir agendamentos
    public void excluir(int id) {

        Espaco espaco = buscarPorId(id);

        for (Agendamento agendamento : agendamentoRepository.listarTodos()) {

            if (agendamento.getEspaco() != null
                    && agendamento.getEspaco().getId() == espaco.getId()) {

                throw new IllegalArgumentException(
                        "Não é possível excluir este espaço, "
                                + "pois existem agendamentos vinculados.");
            }
        }

        repository.excluir(id);
    }

    // Validar dados do espaço
    private void validarDados(
            String nome,
            String tipo,
            int capacidade) {

        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException(
                    "Informe o nome do espaço.");
        }

        if (tipo == null || tipo.isBlank()) {
            throw new IllegalArgumentException(
                    "Informe o tipo do espaço.");
        }

        if (capacidade <= 0) {
            throw new IllegalArgumentException(
                    "A capacidade deve ser maior que zero.");
        }
    }
}
