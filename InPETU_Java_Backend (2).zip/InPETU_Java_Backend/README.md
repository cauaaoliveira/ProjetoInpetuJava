# InPETU Java Backend

## Sobre o projeto

O **InPETU Java Backend** é um projeto acadêmico desenvolvido com Java, com o objetivo de implementar a lógica de funcionamento de um sistema de gerenciamento de espaços e agendamentos do InPETU Hub.

O sistema permite realizar operações de cadastro, consulta, edição e listagem de contatos, espaços e agendamentos, aplicando regras de negócio para garantir a consistência das informações.

## Funcionalidades

### Contatos
- Cadastrar contatos.
- Consultar contato pelo ID.
- Editar informações de um contato.
- Listar todos os contatos.
- Impedir o cadastro de contatos com IDs duplicados.
- Impedir a alteração do ID de um contato.

### Espaços
- Cadastrar espaços.
- Consultar espaço pelo ID.
- Editar informações de um espaço.
- Listar todos os espaços.
- Impedir o cadastro de espaços com IDs duplicados.
- Impedir a alteração do ID de um espaço.
- Impedir a exclusão de espaços que possuem agendamentos vinculados.

### Agendamentos
- Cadastrar agendamentos vinculados a contatos e espaços existentes.
- Consultar agendamento pelo ID.
- Editar informações de um agendamento.
- Listar todos os agendamentos.
- Impedir o cadastro de agendamentos com contatos ou espaços inexistentes.
- Verificar conflitos de horários.
- Impedir agendamentos duplicados para o mesmo contato ou espaço no mesmo período.
- Impedir a alteração do ID de um agendamento.

## Tecnologias utilizadas

- **Java:** linguagem utilizada no desenvolvimento do backend.
- **IntelliJ IDEA:** ambiente de desenvolvimento.
- **Git e GitHub:** controle de versão e compartilhamento do código.

## Estrutura do projeto

```text
InPETU_Java_Backend/
│
├── src/
│   └── inpetu/
│       ├── model/
│       │   ├── Agendamento.java
│       │   ├── Contato.java
│       │   └── Espaco.java
│       │
│       ├── repository/
│       │   ├── IAgendamentoRepository.java
│       │   ├── IContatoRepository.java
│       │   ├── IEspacoRepository.java
│       │   └── memory/
│       │       ├── AgendamentoMemoryRepository.java
│       │       ├── ContatoMemoryRepository.java
│       │       └── EspacoMemoryRepository.java
│       │
│       ├── service/
│       │   ├── AgendamentoService.java
│       │   ├── ContatoService.java
│       │   └── EspacoService.java
│       │
│       └── Application.java
│
└── README.md
```

## Organização da aplicação

O projeto utiliza uma separação por responsabilidades:

- **Model:** representa as entidades do sistema, como Contato, Espaço e Agendamento.
- **Repository:** responsável pelo armazenamento e recuperação dos dados.
- **Service:** concentra as regras de negócio e validações.
- **Application:** ponto de entrada da aplicação, utilizado para executar e testar as funcionalidades.

## Armazenamento dos dados

Atualmente, o projeto utiliza repositórios em memória (*Memory Repository*), com estruturas de dados Java para armazenar as informações durante a execução.

Os dados são temporários e não são mantidos após o encerramento da aplicação.

## Como executar

1. Clone o repositório:
   ```bash
   git clone URL_DO_REPOSITORIO
   ```

2. Abra o projeto no IntelliJ IDEA.

3. Aguarde a configuração e o reconhecimento das classes Java.

4. Localize o arquivo `Application.java`.

5. Execute o método `main()` para iniciar a aplicação.

## Projeto acadêmico

Desenvolvido em grupo como atividade acadêmica, com foco na aplicação dos conceitos de programação orientada a objetos, organização em camadas, repositórios e regras de negócio utilizando Java.